import { Linkedin, Twitter, Mail, Github } from "lucide-react";

const socialLinks = [
  { icon: Linkedin, href: "#", label: "LinkedIn" },
  { icon: Twitter, href: "#", label: "Twitter" },
  { icon: Github, href: "#", label: "GitHub" },
  { icon: Mail, href: "mailto:hello@withsimon.com", label: "Email" },
];

const Footer = () => {
  return (
    <footer className="py-12 section-padding border-t border-border">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-lg bg-foreground text-background flex items-center justify-center font-bold text-sm font-mono">
              ST
            </span>
            <span className="font-bold text-lg uppercase tracking-wide">WithSimon</span>
          </div>

          <div className="flex items-center gap-3">
            {socialLinks.map((social) => (
              <a
                key={social.label}
                href={social.href}
                aria-label={social.label}
                className="w-10 h-10 rounded-lg bg-secondary border border-border flex items-center justify-center text-muted-foreground hover:bg-accent hover:text-accent-foreground hover:border-accent transition-all"
              >
                <social.icon className="w-4 h-4" />
              </a>
            ))}
          </div>

          <p className="text-xs text-muted-foreground font-mono uppercase tracking-wide">
            © {new Date().getFullYear()} Simon Tadeu
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
