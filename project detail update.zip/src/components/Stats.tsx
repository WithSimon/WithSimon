import { motion } from "framer-motion";
import { Rocket, TrendingUp, Users, Award } from "lucide-react";

const stats = [
  { icon: Rocket, value: "20+", label: "Products Built" },
  { icon: TrendingUp, value: "8+", label: "Years Experience" },
  { icon: Users, value: "1M+", label: "Users Served" },
  { icon: Award, value: "15+", label: "Team Members Led" },
];

const Stats = () => {
  return (
    <section className="py-20 section-padding">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => {
            const iconColors = ['text-accent', 'text-highlight', 'text-pink', 'text-yellow'];
            const borderColors = ['border-accent/50', 'border-highlight/50', 'border-pink/50', 'border-yellow/50'];
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="text-center group"
              >
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-xl bg-secondary border border-border mb-4 group-hover:${borderColors[index]} transition-colors`}>
                  <stat.icon className={`w-7 h-7 ${iconColors[index]}`} />
                </div>
                <div className="text-4xl md:text-5xl font-bold text-foreground mb-2 font-mono">
                  {stat.value}
                </div>
                <div className="text-xs text-muted-foreground uppercase tracking-widest font-semibold">{stat.label}</div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Stats;
