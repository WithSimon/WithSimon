import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

const Header = () => {
  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50 bg-background/60 backdrop-blur-xl border-b border-border/30"
    >
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <a href="/" className="flex items-center gap-3 group">
          <span className="w-10 h-10 rounded-lg bg-foreground text-background flex items-center justify-center font-bold text-sm font-mono">
            ST
          </span>
        </a>

        <nav className="hidden md:flex items-center gap-8">
          <NavLink href="/">Home</NavLink>
          <NavLink href="/about">About</NavLink>
          <NavLink href="#work">Projects</NavLink>
          <Button variant="outline" size="sm" className="ml-4 font-semibold uppercase tracking-wide text-xs border-foreground/20 hover:bg-foreground hover:text-background transition-all">
            Get In Touch
          </Button>
        </nav>

        <Button variant="outline" size="sm" className="md:hidden font-semibold uppercase tracking-wide text-xs border-foreground/20">
          Menu
        </Button>
      </div>
    </motion.header>
  );
};

const NavLink = ({ href, children }: { href: string; children: React.ReactNode }) => (
  <a
    href={href}
    className="text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors uppercase tracking-widest"
  >
    {children}
  </a>
);

export default Header;
