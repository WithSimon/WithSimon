import { motion } from "framer-motion";
import { ArrowUpRight, Calendar } from "lucide-react";
import { Link } from "react-router-dom";

const projects = [
  {
    title: "Bond Heart",
    slug: "bond-heart",
    description: "A wearable necklace that lets users feel someone else's heartbeat - led hardware and software from concept to launch",
    category: "Product Management",
    date: "March 2023",
    image: "https://images.unsplash.com/photo-1516962126636-27ad087061cc?w=800&h=600&fit=crop",
  },
  {
    title: "Sample Product Management Project",
    slug: "sample-project",
    description: "A comprehensive product management case study showcasing strategy, execution, and results.",
    category: "Product Strategy",
    date: "December 2024",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop",
  },
];

const FeaturedWork = () => {
  return (
    <section id="work" className="py-24 section-padding">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4 uppercase tracking-tight">
            Projects
          </h2>
          <p className="text-muted-foreground max-w-2xl font-mono text-sm">
            A selection of impactful products and features I've brought to life, 
            from concept to launch and beyond.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.article
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15, duration: 0.5 }}
              className="group"
            >
              <Link to={`/project/${project.slug}`}>
                <div className="relative overflow-hidden rounded-xl mb-6 border border-border">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full aspect-[4/3] object-cover transition-transform duration-500 group-hover:scale-105 grayscale group-hover:grayscale-0"
                  />
                  <div className="absolute inset-0 bg-background/0 group-hover:bg-highlight/10 transition-colors duration-300" />
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1.5 bg-background/90 backdrop-blur-sm rounded-full text-xs font-semibold text-highlight uppercase tracking-wide border border-highlight/30">
                      {project.category}
                    </span>
                  </div>
                  <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="w-12 h-12 rounded-full bg-pink flex items-center justify-center">
                      <ArrowUpRight className="w-5 h-5 text-pink-foreground" />
                    </div>
                  </div>
                </div>

                <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-highlight transition-colors uppercase tracking-wide">
                  {project.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-3 line-clamp-2 font-mono">
                  {project.description}
                </p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
                  <Calendar className="w-3.5 h-3.5" />
                  {project.date}
                </div>
              </Link>
            </motion.article>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="mt-12"
        >
          <Link
            to="#"
            className="inline-flex items-center gap-2 text-pink font-semibold hover:underline underline-offset-4 uppercase tracking-wide text-sm"
          >
            View All Projects
            <ArrowUpRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturedWork;
