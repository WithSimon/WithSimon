import { motion } from "framer-motion";

const skills = [
  "Product Strategy",
  "★",
  "Team Leadership",
  "★",
  "User Research",
  "★",
  "Data-Driven",
  "★",
  "Agile Expert",
  "★",
  "Cross-Functional",
  "★",
  "Product Strategy",
  "★",
  "Team Leadership",
  "★",
  "User Research",
  "★",
  "Data-Driven",
  "★",
  "Agile Expert",
  "★",
  "Cross-Functional",
  "★",
];

const Marquee = () => {
  return (
    <div className="py-6 overflow-hidden border-y border-border bg-secondary/30">
      <motion.div
        className="flex whitespace-nowrap"
        animate={{ x: ["0%", "-50%"] }}
        transition={{
          x: {
            duration: 20,
            repeat: Infinity,
            ease: "linear",
          },
        }}
      >
        {skills.map((skill, index) => {
          const starColors = ['text-accent', 'text-highlight', 'text-pink', 'text-yellow'];
          const starColorClass = starColors[Math.floor(index / 2) % 4];
          return (
            <span
              key={index}
              className={`mx-4 text-sm font-semibold uppercase tracking-widest ${
                skill === "★" ? starColorClass : "text-foreground/80"
              }`}
            >
              {skill}
            </span>
          );
        })}
      </motion.div>
    </div>
  );
};

export default Marquee;
