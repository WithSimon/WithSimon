import { motion } from "framer-motion";
import { ArrowRight, MapPin, Sparkles, Mic, BookOpen, Code } from "lucide-react";
import simonPortrait from "@/assets/simon-portrait.jpg";
import { Button } from "@/components/ui/button";

const tags = [
  { icon: Sparkles, label: "Building Products" },
  { icon: Mic, label: "Speaker" },
  { icon: BookOpen, label: "Mentor" },
  { icon: Code, label: "Tech" },
];

const Hero = () => {
  return (
    <section className="min-h-screen pt-24 pb-16 section-padding flex items-center relative overflow-hidden">
      <div className="max-w-6xl mx-auto w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="order-2 lg:order-1"
          >
            {/* Pill Tags */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="flex flex-wrap gap-2 mb-8"
            >
              {tags.map((tag, index) => {
                const colors = ['text-accent', 'text-highlight', 'text-pink', 'text-yellow'];
                return (
                  <motion.span
                    key={tag.label}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.4 + index * 0.1 }}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-border text-sm font-medium text-foreground hover:bg-muted transition-colors cursor-default"
                  >
                    <tag.icon className={`w-4 h-4 ${colors[index]}`} />
                    {tag.label}
                  </motion.span>
                );
              })}
            </motion.div>

            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-foreground leading-none mb-2 tracking-tight uppercase">
              Simon
            </h1>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-foreground leading-none mb-6 tracking-tight uppercase">
              Tadeu
            </h1>

            <h2 className="text-lg md:text-xl font-semibold text-foreground/90 uppercase tracking-widest mb-6">
              Senior Product Manager
            </h2>

            <p className="text-base text-muted-foreground leading-relaxed mb-8 max-w-lg font-mono text-sm">
              Seasoned product leader with 8+ years of experience, driving product
              innovation at scale. Expert in building high-performing teams, 
              delivering impactful products, and advocating for users.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button size="lg" className="group font-semibold uppercase tracking-wide">
                Get In Touch
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
              <Button variant="outline" size="lg" className="font-semibold uppercase tracking-wide border-foreground/20 hover:bg-pink hover:text-pink-foreground hover:border-pink transition-all duration-200">
                View Projects
              </Button>
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="flex items-center gap-2 text-sm text-muted-foreground font-mono"
            >
              <span className="inline-block w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span>Currently at</span>
              <a
                href="https://www.iterable.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="font-semibold text-foreground hover:text-accent transition-colors underline underline-offset-2"
              >
                Iterable
              </a>
            </motion.div>
          </motion.div>

          {/* Portrait */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="order-1 lg:order-2 flex justify-center lg:justify-end"
          >
            <div className="relative">
              {/* Multiple layered shadows */}
              <div className="absolute inset-0 bg-highlight/40 rounded-full translate-x-3 translate-y-3" />
              <div className="absolute inset-0 bg-pink/30 rounded-full translate-x-1.5 translate-y-1.5" />
              <img
                src={simonPortrait}
                alt="Simon Tadeu"
                className="relative w-72 h-72 md:w-80 md:h-80 lg:w-96 lg:h-96 object-cover rounded-full border-4 border-foreground/10"
              />
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2 }}
                className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-card px-4 py-2 rounded-full shadow-card flex items-center gap-2 border border-border whitespace-nowrap"
              >
                <MapPin className="h-4 w-4 text-pink" />
                <span className="text-sm font-medium font-mono">Lisbon, Portugal</span>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
