import { motion } from "framer-motion";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { 
  Coffee, Music, Plane, BookOpen, Gamepad2, Camera, 
  Heart, Mountain, Utensils, Dog
} from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const funFacts = [
  { icon: Coffee, label: "Coffee Addict", description: "3+ cups daily minimum", color: "text-accent" },
  { icon: Music, label: "Music Lover", description: "From jazz to electronic", color: "text-highlight" },
  { icon: Plane, label: "Travel Bug", description: "15+ countries visited", color: "text-pink" },
  { icon: BookOpen, label: "Avid Reader", description: "Sci-fi & business books", color: "text-yellow" },
  { icon: Gamepad2, label: "Gamer", description: "Strategy & RPGs", color: "text-accent" },
  { icon: Camera, label: "Photography", description: "Street & landscape", color: "text-highlight" },
  { icon: Mountain, label: "Hiking", description: "Weekend trail explorer", color: "text-pink" },
  { icon: Utensils, label: "Foodie", description: "Always trying new cuisines", color: "text-yellow" },
];

const workHistory = [
  {
    id: "role-1",
    company: "TechCorp Inc.",
    role: "Senior Product Manager",
    period: "2022 – Present",
    description: "Leading product strategy for B2B SaaS platform. Managed cross-functional team of 12, launched 3 major features resulting in 40% revenue growth.",
    highlights: ["Product Strategy", "Team Leadership", "Revenue Growth"],
  },
  {
    id: "role-2",
    company: "StartupXYZ",
    role: "Product Manager",
    period: "2019 – 2022",
    description: "Built mobile app from 0 to 100k users. Defined product roadmap, conducted user research, and collaborated with engineering on agile sprints.",
    highlights: ["Mobile App", "User Research", "Agile"],
  },
  {
    id: "role-3",
    company: "Enterprise Solutions",
    role: "Associate Product Manager",
    period: "2017 – 2019",
    description: "Supported product development for enterprise clients. Gathered requirements, wrote specs, and coordinated with stakeholders across departments.",
    highlights: ["Enterprise", "Requirements", "Stakeholder Management"],
  },
  {
    id: "role-4",
    company: "Digital Agency Co.",
    role: "Business Analyst",
    period: "2015 – 2017",
    description: "Analyzed client needs and translated them into actionable product requirements. Created wireframes and user flows for web applications.",
    highlights: ["Analysis", "Wireframes", "Client Relations"],
  },
];

const About = () => {
  const highlightColors = ["bg-accent/20 text-accent", "bg-highlight/20 text-highlight", "bg-pink/20 text-pink", "bg-yellow/20 text-yellow"];

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="pt-32 pb-20">
        {/* Page Header */}
        <section className="max-w-4xl mx-auto px-6 mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-xs font-mono uppercase tracking-widest text-accent mb-4 block">
              // About Me
            </span>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              The Person Behind<br />
              <span className="text-muted-foreground">the Products</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Beyond the roadmaps and sprints, here's a glimpse into who I am — 
              my passions, quirks, and the professional journey that shaped me.
            </p>
          </motion.div>
        </section>

        {/* Fun Facts Section */}
        <section className="max-w-4xl mx-auto px-6 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h2 className="text-2xl font-bold mb-8 flex items-center gap-3">
              <Heart className="w-6 h-6 text-pink" />
              Fun Facts & Interests
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {funFacts.map((fact, index) => (
                <motion.div
                  key={fact.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.3 + index * 0.05 }}
                  className="group bg-card/50 backdrop-blur-sm border border-border/50 rounded-xl p-5 hover:border-border hover:bg-card/80 transition-all cursor-default"
                >
                  <fact.icon className={`w-8 h-8 ${fact.color} mb-3 group-hover:scale-110 transition-transform`} />
                  <h3 className="font-semibold text-sm mb-1">{fact.label}</h3>
                  <p className="text-xs text-muted-foreground">{fact.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* Work History Section */}
        <section className="max-w-4xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <h2 className="text-2xl font-bold mb-8 flex items-center gap-3">
              <BookOpen className="w-6 h-6 text-accent" />
              Work Experience
            </h2>

            <Accordion type="single" collapsible className="space-y-3">
              {workHistory.map((job, index) => (
                <AccordionItem 
                  key={job.id} 
                  value={job.id}
                  className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-xl px-6 data-[state=open]:border-border data-[state=open]:bg-card/80 transition-all"
                >
                  <AccordionTrigger className="hover:no-underline py-5">
                    <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-6 text-left w-full pr-4">
                      <span className="text-xs font-mono text-muted-foreground whitespace-nowrap">
                        {job.period}
                      </span>
                      <div className="flex-1">
                        <h3 className="font-semibold">{job.role}</h3>
                        <p className="text-sm text-muted-foreground">{job.company}</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pb-5">
                    <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                      {job.description}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {job.highlights.map((highlight, hIndex) => (
                        <span 
                          key={highlight}
                          className={`text-xs font-medium px-3 py-1 rounded-full ${highlightColors[hIndex % highlightColors.length]}`}
                        >
                          {highlight}
                        </span>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default About;
