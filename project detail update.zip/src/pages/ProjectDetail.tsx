import { motion } from "framer-motion";
import { ArrowLeft, Calendar, Tag } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Badge } from "@/components/ui/badge";

// Project data - this would typically come from a CMS or API
const projects = {
  "bond-heart": {
    title: "Bond Heart",
    description: "A wearable necklace that lets users feel someone else's heartbeat - led hardware and software from concept to launch",
    thumbnail: "https://images.unsplash.com/photo-1516962126636-27ad087061cc?w=1600&h=900&fit=crop",
    category: "Product Management",
    date: "March 2023",
    tags: ["Hardware", "Wearables", "IoT", "Product Strategy"],
    sections: [
      {
        title: "Context",
        color: "highlight",
        content: `Bond Heart is a wearable necklace from Bond Touch designed to let users feel someone else's heartbeat. As the Senior Product Manager, I led this project from concept to launch, overseeing both software and hardware.

The team included iOS and Android developers, QA specialists, a user researcher, three designers over time, and a hardware/firmware team based in China. It was a typical startup setup: lean, fast-moving, and occasionally chaotic, but ultimately rewarding.`
      },
      {
        title: "Problem",
        color: "pink",
        content: `Bond Touch had seen success with its initial product, but growth was starting to level off. The user base was heavily centered on couples in long-distance relationships, which limited expansion.

When relationships ended, the product often lost relevance for those users. The challenge was to expand emotional connection use cases beyond LDRs, without diluting or disrupting the core experience that existing users valued.`
      },
      {
        title: "Solution",
        color: "accent",
        content: `Bond Heart was built to complement, not replace, the existing Bond Touch product. The MVP focused on a simple idea: record a heartbeat, send it, feel it.

Key decisions included:
• Expanding use cases to parents, friends, and other non-romantic relationships
• Allowing non-users to send heartbeats
• Preserving distinct experiences through dual dashboards
• Prioritizing emotional resonance over technical or medical-grade precision`
      },
      {
        title: "Execution",
        color: "yellow",
        content: `Discovery began in early 2022 with proof-of-concepts, internal testing, and beta programs. I worked closely with the CEO to refine product strategy while managing trade-offs between battery life, design constraints, and hardware capabilities.

Final hardware and firmware validation took place on-site in Hong Kong. In parallel, I partnered with customer support and marketing to prepare for launch and ensure the product landed smoothly.`
      },
      {
        title: "Results & Takeaways",
        color: "highlight",
        content: `Bond Heart launched in March 2023 at a $99 price point with strong early results:
• ~10% increase in overall sales
• ~20% of active Bond Touch users also became active Bond Heart users
• Engagement averaged ~8 heartbeats per user per day
• The audience skewed older than initially expected

Key takeaways:
• New products can grow an ecosystem without cannibalizing the core if boundaries are clear
• Hardware decisions need to happen earlier than feels comfortable
• For emotionally driven products, simplicity often beats technical perfection`
      },
    ],
  },
};

const colorClasses: Record<string, { bg: string; border: string; bullet: string }> = {
  highlight: { bg: "bg-highlight/20", border: "border-highlight/40", bullet: "bg-highlight" },
  pink: { bg: "bg-pink/20", border: "border-pink/40", bullet: "bg-pink" },
  accent: { bg: "bg-accent/20", border: "border-accent/40", bullet: "bg-accent" },
  yellow: { bg: "bg-yellow/20", border: "border-yellow/40", bullet: "bg-yellow" },
};

// Helper to render styled content with bullet points and subsections
const renderStyledContent = (content: string, bulletColor: string) => {
  const lines = content.split('\n');
  const elements: React.ReactNode[] = [];
  let currentParagraph: string[] = [];
  let inBulletList = false;
  let bulletItems: string[] = [];

  const flushParagraph = () => {
    if (currentParagraph.length > 0) {
      elements.push(
        <p key={`p-${elements.length}`} className="text-muted-foreground font-mono text-sm leading-relaxed mb-4">
          {currentParagraph.join('\n')}
        </p>
      );
      currentParagraph = [];
    }
  };

  const flushBulletList = () => {
    if (bulletItems.length > 0) {
      elements.push(
        <ul key={`ul-${elements.length}`} className="space-y-2 mb-4">
          {bulletItems.map((item, idx) => (
            <li key={idx} className="flex items-start gap-3">
              <span className={`w-2 h-2 rounded-full ${bulletColor} mt-1.5 shrink-0`} />
              <span className="text-muted-foreground font-mono text-sm leading-relaxed">{item}</span>
            </li>
          ))}
        </ul>
      );
      bulletItems = [];
      inBulletList = false;
    }
  };

  lines.forEach((line, idx) => {
    const trimmedLine = line.trim();
    
    // Check for subsection headers (lines ending with ":")
    if (trimmedLine.match(/^[A-Z][^•\n]*:$/)) {
      flushParagraph();
      flushBulletList();
      elements.push(
        <h3 key={`h3-${elements.length}`} className="text-foreground font-bold text-sm uppercase tracking-wider mt-6 mb-3 flex items-center gap-2">
          <span className={`w-1 h-4 rounded-full ${bulletColor}`} />
          {trimmedLine}
        </h3>
      );
      return;
    }
    
    // Check for bullet points
    if (trimmedLine.startsWith('•')) {
      flushParagraph();
      inBulletList = true;
      bulletItems.push(trimmedLine.replace('•', '').trim());
      return;
    }
    
    // Regular text or empty line
    if (inBulletList && trimmedLine === '') {
      flushBulletList();
    } else if (trimmedLine === '') {
      flushParagraph();
    } else {
      if (inBulletList) {
        flushBulletList();
      }
      currentParagraph.push(line);
    }
  });

  flushParagraph();
  flushBulletList();

  return <div className="space-y-0">{elements}</div>;
};

const ProjectDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const project = projects[slug as keyof typeof projects];

  if (!project) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-foreground mb-4">Project Not Found</h1>
            <Link to="/" className="text-pink hover:underline">
              ← Back to Home
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const [contextSection, ...otherSections] = project.sections;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Back Navigation */}
        <div className="section-padding pt-8">
          <div className="max-w-6xl mx-auto">
            <Link 
              to="/#work" 
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-pink transition-colors font-mono text-sm"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Projects
            </Link>
          </div>
        </div>

        {/* Hero Section */}
        <section className="section-padding py-8">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* Meta Info */}
              <div className="flex flex-wrap items-center gap-4 mb-6">
                <Badge variant="outline" className="border-highlight text-highlight">
                  {project.category}
                </Badge>
                <span className="flex items-center gap-2 text-muted-foreground font-mono text-sm">
                  <Calendar className="w-4 h-4" />
                  {project.date}
                </span>
              </div>

              {/* Title */}
              <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-4 uppercase tracking-tight">
                {project.title}
              </h1>

              {/* Description */}
              <p className="text-lg text-muted-foreground max-w-3xl font-mono">
                {project.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mt-6">
                {project.tags.map((tag) => (
                  <span
                    key={tag}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-secondary rounded-full text-xs font-mono text-secondary-foreground"
                  >
                    <Tag className="w-3 h-3" />
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Full-Width Hero Image */}
        <motion.section
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="section-padding pb-12"
        >
          <div className="max-w-6xl mx-auto">
            <div className="relative overflow-hidden rounded-2xl border border-border">
              <img
                src={project.thumbnail}
                alt={project.title}
                className="w-full aspect-[16/9] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
            </div>
          </div>
        </motion.section>

        {/* Context Section - Full Width */}
        <section className="section-padding pb-12">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            className={`rounded-2xl border overflow-hidden bg-card ${colorClasses[contextSection.color].border}`}
            >
              {/* Card Header with Title */}
              <div className={`px-6 py-4 ${colorClasses[contextSection.color].bg} flex items-center gap-4`}>
                <div className="w-10 h-10 rounded-lg bg-background/80 backdrop-blur-sm flex items-center justify-center border border-border shrink-0">
                  <span className="text-xl">📋</span>
                </div>
                <h2 className="text-2xl font-bold text-foreground uppercase tracking-wide">
                  {contextSection.title}
                </h2>
              </div>
              
              {/* Card Content */}
              <div className="p-8">
                {renderStyledContent(contextSection.content, colorClasses[contextSection.color].bullet)}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Two-Column Grid for Remaining Sections */}
        <section className="section-padding pb-24">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8">
              {otherSections.map((section, index) => {
                const icons: Record<string, string> = {
                  "Problem": "⚠️",
                  "Solution": "💡",
                  "Execution": "🚀",
                  "Results & Takeaways": "📊",
                };
                
                return (
                  <motion.div
                    key={section.title}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className={`rounded-2xl border overflow-hidden bg-card ${colorClasses[section.color].border}`}
                  >
                    {/* Card Header with Title */}
                    <div className={`px-5 py-4 ${colorClasses[section.color].bg} flex items-center gap-3`}>
                      <div className="w-10 h-10 rounded-lg bg-background/80 backdrop-blur-sm flex items-center justify-center border border-border shrink-0">
                        <span className="text-xl">{icons[section.title] || "📝"}</span>
                      </div>
                      <h2 className="text-xl font-bold text-foreground uppercase tracking-wide">
                        {section.title}
                      </h2>
                    </div>
                    
                    {/* Card Content */}
                    <div className="p-6">
                      {renderStyledContent(section.content, colorClasses[section.color].bullet)}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default ProjectDetail;
